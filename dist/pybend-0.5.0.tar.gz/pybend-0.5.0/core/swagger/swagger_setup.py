# app/swagger/swagger_setup.py

# This file is intentionally left empty as we are using Flasgger,
# which is initialized directly in main.py with `Swagger(app)`.
